import React,{useState} from 'react'
import { useHistory } from 'react-router-dom';
import Card from 'react-credit-cards'
import './CardPayment.css'
import * as hisApiCall from '../BookedTicket/HistoryApifunc'
import jwt_decode from 'jwt-decode'

import {
    formatCreditCardNumber,
    formatCVC,
    formatExpirationDate,
    formatFormData
} from './utils'
import 'react-credit-cards/es/styles-compiled.css'

export default class App extends React.Component {
    state = {
        number: '',
        name: '',
        expiry: '',
        cvc: '',
        issuer: '',
        focused: '',
        formData: '',
        token: ''
    }
    history={};
    tktDetails= {};
    componentDidMount() {
        // const tok = sessionStorage.getItem('authToken')
        // const decoded = jwt_decode(tok)
        // this.setState({ token: decoded.user })
        //this.history = useHistory();
        this.tktDetails= 
            {
                email:localStorage.getItem("loginuseremail"),
                companyName:localStorage.getItem('company'),
                startCity:localStorage.getItem('start'),
                destination:localStorage.getItem('destination'),
                pricePerSeat:localStorage.getItem("price"),
                passengers: localStorage.getItem('nameData') ,
                seatNumbers:localStorage.getItem('reservedSeats'),
                journeydate:localStorage.getItem('date'),
                //bookingdate:localStorage.getItem('date'),
                totalamount:this.getSumTotal(true),
                starttime:localStorage.getItem('starttime')

            };
            console.log(this.tktDetails)
    }   

    handleCallback = ({ issuer }, isValid) => {
        if (isValid) {
            this.setState({ issuer })
        }
    }

    handleBackChooseSeat = (e) => {
        e.preventDefault()
        this.props.handleActiveMenu(true,false)
    }

    handleInputFocus = ({ target }) => {
        this.setState({
            focused: target.name
        })
    }

    handleInputChange = ({ target }) => {
        if (target.name === 'number') {
            target.value = formatCreditCardNumber(target.value)
        } else if (target.name === 'expiry') {
            target.value = formatExpirationDate(target.value)
        } else if (target.name === 'cvc') {
            target.value = formatCVC(target.value)
        }

        this.setState({
            [target.name]: target.value
        })
    }

    handleSubmit = e => {
        e.preventDefault()
        const { issuer } = this.state
        const formData = [...e.target.elements]
            .filter(d => d.name)
            .reduce((acc, d) => {
                acc[d.name] = d.value
                return acc
            }, {})

        this.setState({ formData })
        this.form.reset()
    }

    saveAndMoveToTicketPage = e => {
        e.preventDefault()
        console.log(this.state)
        if(this.state.number==''||this.state.cvc==''||this.state.expiry=='')
        {
            alert('Please make payment!')
        }
        else{
        localStorage.setItem('paymentData', JSON.stringify(this.state.token))
        this.tktDetails= 
            {
                email:localStorage.getItem("loginuseremail"),
                companyName:localStorage.getItem('company'),
                startCity:localStorage.getItem('start'),
                destination:localStorage.getItem('destination'),
                pricePerSeat:localStorage.getItem("price"),
                passengers: localStorage.getItem('nameData') ,
                seatNumbers:localStorage.getItem('reservedSeats'),
                journeydate:localStorage.getItem('date'),
                //bookingdate:new Date().toLocaleString(),
                busId:localStorage.getItem('selectedBusId'),
                totalamount:this.getSumTotal(true),
                starttime:localStorage.getItem('starttime'),
                food:localStorage.getItem('food')

            };
            
            console.log(this.tktDetails)
            hisApiCall.postHistoryToApi(this.tktDetails)
                .then(response => response.data)
                .then(data => {
                    //setData(data)
                    console.log("Saved history:", data)    
                    localStorage.setItem('ticketId',data._id)          
                })
        //window.location.href = '/getTicket'
        //const { history } = this.props;
        localStorage.setItem('isFromHistory',false)
        this.props.history.push('/getTicket')
        //console.log(this.props)
        }
    }

    renderNamesOfPassenger = () => {
        let passArray = localStorage.getItem('nameData')
        console.log(passArray)
        if (passArray) {
            let nameArray = JSON.parse(passArray)
            return nameArray.map((name, idx) => {
                return <p key={idx} > {name} </p>
            })
        }
    }

    renderSeatNumbers = () => {
                        let seatArray = localStorage.getItem('reservedSeats')
                    if (seatArray) {
                        let seaArr = JSON.parse(seatArray)
            return seaArr.map((seat, idx) => {
                return <p key={idx} > {seat} </p>
            })
        }
    }

    getSumTotal = (isJustAmount) => {
                        let count = 0
                        let tax = 150
                        let price =localStorage.getItem("price")
                        //console.log(price)
                        let seatArray = localStorage.getItem('reservedSeats')
                        if (seatArray) {
                            let seaArr = JSON.parse(seatArray)
                            count = seaArr.length
                        // for (let i = 0; i < seaArr.length; i++) {
                        //     count++
                        // }
                        if(isJustAmount)
                        {
                           return (price * count + tax)
                        }
                        else
                        {
                            return ( <div>
                                <hr className='hr3' />
                                <p> {price * count} </p> <p> +{tax} </p > < p > {price * count + tax} </p>{' '} 
                                </div>
                                        )
                        }
        }
    }

    render() {
        const {
            name,
            number,
            expiry,
            cvc,
            focused,
            issuer,
            formData,
            token
        } = this.state

        return (
            
            <div className='paym' >
                <div>
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                    
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                            <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => this.handleBackChooseSeat(e)}>Back</a>
                            </li>                           
                        </ul>
                    </div>
                </nav>
            </div>
                <div className='row' >
                    <div key='Payment' >
                        <div className='App-payment cl-1' >
                            <p className='pPayment' > Enter card details </p>{' '} <
                                Card number={number}
                                name={name}
                                expiry={expiry}
                                cvc={cvc}
                                focused={focused}
                                callback={this.handleCallback}
                            />{' '} <form className='credit-form'
                                ref={c => (this.form = c)}
                                onSubmit={this.handleSubmit} >
                                <div className='form-group' >
                                    <
                                        input type='tel'
                                        name='number'
                                        className='frm-ctrl'
                                        placeholder='Card Number'
                                        pattern='[\d| ]{16,22}'
                                        required onChange={this.handleInputChange}
                                        onFocus={this.handleInputFocus}
                                    />{' '} </div>{' '}
                                <div className='form-group' >
                                    <
                                        input type='text'
                                        name='name'
                                        className='frm-ctrl'
                                        placeholder='Name'
                                        required onChange={this.handleInputChange}
                                        onFocus={this.handleInputFocus}
                                    />{' '} </div>{' '}
                                <div className='form-group' >
                                    <
                                        input type='tel'
                                        name='expiry'
                                        className='frm-ctrl'
                                        placeholder='Valid Thru'
                                        pattern='\d\d/\d\d'
                                        required onChange={this.handleInputChange}
                                        onFocus={this.handleInputFocus}
                                    />{' '} </div>{' '}
                                <div className='form-group' >
                                    <
                                        input type='tel'
                                        name='cvc'
                                        className='frm-ctrl cvc'
                                        placeholder='CVC'
                                        pattern='\d{3,4}'
                                        required onChange={this.handleInputChange}
                                        onFocus={this.handleInputFocus}
                                    />{' '} </div>{' '} <
                                    input type='hidden'
                                    name='issuer'
                                    value={issuer}
                                />{' '} <div className='' >
                                    <button onClick={e => this.saveAndMoveToTicketPage(e)}
                                        className='btn btn-light btCustom' >
                                        PAY {' '}
                                    </button>{' '}
                                </div>{' '}
                            </form>{' '}
                        </div>{' '}
                    </div>{' '}
                    {
                        
                    
                    /* <div className='columnTwo' >
                        <h3> KLU Travels </h3>{' '}
                        <div>
                            <p> BOOKING DETAILS </p>{''}
                            <div className='row' >
                                <div className='col-6 pt' >
                                    <p className='hdng' > Username </p> <hr className='hr3' />
                                    <p className='hdng' > Date </p> <p className='hdng'> From </p >
                                    <p className='hdng' > To </p> <hr className='hr3' />
                                    <p className='hdng' > Passengers </p>{' '} {this.renderNamesOfPassenger()} < hr className='hr3' />
                                    <p className='hdng' > Ticket price </p>{' '}
                                    <p className='hdng' > Tax </p>{' '}
                                    <p className='hdng' > Toal Sum </p>{' '}
                                </div>{' '}
                                <div className='col-6' >
                                    <hr className='hr3' />
                                    <p className='usrName' > {' '} {localStorage.getItem('date')} {' '}
                                    </p>{' '} <p className='usrName' > {localStorage.getItem('start')} </p>{' '}
                                    <p className='usrName' > {' '} {localStorage.getItem('destination')} {' '}</p>{' '}
                                    <hr className='hr3' />
                                    <p className='hdng' >Seat No {' '} </p> {this.renderSeatNumbers()} <p> {this.getSumTotal()} </p >
                                </div>{' '} </div>{' '} </div>{' '}
                    </div>{' '} */}
                </div>{' '}
            </div>)
    }
}