import React,{useState, useEffect} from 'react'
import BusRouteSelection from '../BusRouteSelection/BusRouteSelection'
import BusChooseSeat from '../BusChooseSeat/BusChooseSeat'
import CardPayment from '../CardPayment/CardPayment'
import './BusBooking.css'

export default function BusBooking({ history }) {
    const [homeActive, SetIsHomeActive] = useState(true)
    const [seatActive, SetIsSeatActive] = useState(false)
    const [paymentActive, SetIsPaymentActive] = useState(false)
    const [reservedSeats, setReservedSeats] = useState([])
       
    const setReservedSeatFunc=(resSeats)=>
    {
        setReservedSeats(resSeats)
    }
    const getReservedSeats=()=>
    {
        return reservedSeats;
    }
    const handleActiveMenu =(isSeatActive,isPayActive)=>{
        console.log("handleActiveMenu",isSeatActive,isPayActive)
        if(isSeatActive)
        {
            SetIsHomeActive(false)
            SetIsSeatActive(true)
            SetIsPaymentActive(false)
        }
        else if(isPayActive)
        {
            SetIsHomeActive(false)
            SetIsSeatActive(false)
            SetIsPaymentActive(true)
        }
        else
        {
            SetIsHomeActive(true)
            SetIsSeatActive(false)
            SetIsPaymentActive(false)
        }

    }
    // const handleUserIcon = e => {
    //     e.preventDefault()
    //     history.push('/profile')
    // }

    const handleUserSignOut = e => {
        e.preventDefault()
        sessionStorage.removeItem('authToken')
        localStorage.removeItem('reservedSeats')
        localStorage.removeItem('nameData')
        localStorage.clear()
        history.push('/')
    }
    const handleHistory=e => {
        e.preventDefault()        
        history.push('/history')
    }
    const handleLogoClick = e => {
        e.preventDefault()
        history.push('/booking')
    }
    
    return (
        <div className="container">
            <div>
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                    <a href="/#" className="navbar-brand Company-Log" onClick={(e) => handleLogoClick(e)}>KLU Travels</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3" aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                            <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => handleHistory(e)}>Booking History</a>
                            </li>
                            <li className="nav-item">
                                <a href="#" className="nav-link waves-effect waves-light" ><i className="fa fa-user user"></i></a>
                            </li>
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleUserSignOut(e)}>Sign-Out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div>
                <ul className="nav nav-pills">
                    <h2>Ticket Booking</h2>
                    {/* <li className="nav-item">
                        <a className={homeActive?"nav-link active show":"nav-link"} data-toggle="pill" href="#home">Search Bus</a>
                    </li>
                    <li className="nav-item">
                        <a className={seatActive?"nav-link active show":"nav-link"} data-toggle="pill" href="#menu1">Choose Seat</a>
                    </li>
                    <li className="nav-item">
                        <a className={paymentActive?"nav-link active show":"nav-link"} data-toggle="pill" href="#menu2">Pay Amount</a>
                    </li> */}
                </ul>

                <div className="tab-content">
                    <div className={homeActive?"tab-pane container mn-box active show":"tab-pane container fade mn-box"} id="home"><BusRouteSelection handleActiveMenu={handleActiveMenu} setReservedSeatFunc={setReservedSeatFunc}/></div>
                     <div className={seatActive?"tab-pane container mn-box active show":"tab-pane container fade mn-box"} id="menu1"><BusChooseSeat handleActiveMenu={handleActiveMenu} getReservedSeats={getReservedSeats} /></div>
                     <div className={paymentActive?"tab-pane container mn-box active show":"tab-pane container fade mn-box"} id="menu2"> <CardPayment history={history} handleActiveMenu={handleActiveMenu} /></div>
                </div>
            </div>

        </div>
    )
}
