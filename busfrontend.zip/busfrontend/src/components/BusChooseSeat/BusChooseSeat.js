import React, { useState,useEffect } from 'react'
import './Tab.css'


export default function BusChooseSeat({handleActiveMenu: handleActiveMenu,getReservedSeats:getReservedSeats}) {
    const [name, setName] = useState([])
    const [arrowDown, setArrowDown] = useState(false)
    const [gender, setGender] = useState([])
    //const [reservedSeat, setReservedSeat] = useState(["1A", "2A", "2B", "3B", "4A", "5C", "6A", "7B", "7C", '8B', "9B", "9C"])
    const [reservedSeat, setReservedSeat] = useState([])
    const [seatNumber, setSeatnumber] = useState([])
    const [passengers, setPassengers] = useState([])
    const busActualSeats=[["1A", "1B","1C"],["2A", "2B","2C"],["3A", "3B","3C"],["4A","4B","4C"],["5A","5B","5C"],["6A","6B","6C"], ["7A","7B", "7C"],["8A","8B","8C"],["9A", "9B", "9C"]]
    const [food, setFood] = useState([])
    useEffect(()=>{
        setReservedSeat(getReservedSeats());
        //console.log("Choose seat:reseverdSeats",reservedSeat)

    })
    const handleFood=(e,fooditm)=>
    {
        e.preventDefault()     
        setFood(food.concat((food.length+1)+"."+fooditm)) 
        console.log(food)
    }
    const handleRemoveFood = (e,fooditm) => {
        e.preventDefault()
        console.log(fooditm)
        setFood(food.filter(itm => itm !== fooditm))
        console.log(food)
      }
    const renderSelectedFood = () => {
       
            return food.map((item, idx) => {
                return (
                    // <form key={idx} className="form seatfrm"> 

                        <a href="#" onClick={e => handleRemoveFood(e,item)} title={item} className="nav-link  waves-effect waves-light" >{item}</a>
                    
                    // </form>
                    )

            })
       
    }
   
    const handleBack = (e) => {
        e.preventDefault()
        handleActiveMenu(false,false)
    }
   //console.log("Bus Choose seat : reservedSeats",reservedSeats)
    const handleSelectedSeatNumber = (e) => {
        //setReservedSeat(getReservedSeats()) 
        //console.log("check disabled:",e.disabled)      
        let newSeat = e.target.value
        //console.log(seatNumber.includes(newSeat))
        if (seatNumber.includes(newSeat)) {           
            setSeatnumber(seatNumber.filter(seat => seat !== newSeat))
        } else {
            setSeatnumber([...seatNumber, newSeat])
            //setReservedSeat([...reservedSeat, newSeat])
           // console.log(seatNumber)
           
        }
       // renderPassengerData(seatNumber)
    }
    const handleGender = (e, seatNo) => {
        const { value } = e.target
        setGender(gender.concat(value))
        // console.log(value)
        // setPassengers(prevState => ({ ...prevState, SeatNo: seatNo, Gender: value }))
    }
    const handlePassengerName = (e, seatNo) => {
        e.preventDefault()
        let value = e.target.value
        console.log(value)
        if (!value) {
            alert("name is required")
        } else {
            setName(name.concat(value))
            setPassengers(prevState => ({ ...prevState, SeatNo: seatNo, Name: value }))
        }
    }
    const handleSubmitPassengerDetails = e => {
        e.preventDefault()
        if(name.length==0 || gender.length==0)
        {
            alert("Name and Gender are required!")
            setArrowDown(false)
        }
        else
        {
            handleActiveMenu(false,true)
            setArrowDown(true)
            localStorage.setItem("reservedSeats", JSON.stringify(seatNumber))
            localStorage.setItem("nameData", JSON.stringify(name))
            localStorage.setItem("food", JSON.stringify(food))
        }
        console.log(name)
        console.log(gender)
    }

    const renderPassengerData = (seatArray) => {
        return seatArray.map((seat, idx) => {
            return (
                <form key={idx} className="form seatfrm">
                    <p className="text-capitalize text-center">Seat No:{seat}</p>
                    <input required className="form-control seatInp" onBlurCapture={e => handlePassengerName(e, seat)} type="text" name="passenger-name" placeholder="Enter Name" />
                    <div className="form-check form-check-inline">
                        <input required className="form-check-input" type="radio" name="gender" id="male" value="Male" onClick={e => handleGender(e, seat)} />
                        <label className="form-check-label" htmlFor="male">Male</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input required className="form-check-input" type="radio" name="gender" id="female" value="Female" onClick={e => handleGender(e, seat)} />
                        <label className="form-check-label" htmlFor="female">Female</label>
                    </div>
                </form>)

        })
    }
    const checkDisableSeat=(ele)=>
    {
       // console.log("ele",ele,reservedSeat, reservedSeat.indexOf(ele))
        return (reservedSeat.indexOf(ele)>=0?"disabled":"" )
    }
    const displaySeatNumbers = ()=>{
       // console.log("displaySeatNumbers",reservedSeat)
       return busActualSeats.map((ele,idx)=>{
            // return ele.map((inele,indx)=>{
                return (
                        <li className="row row--"{...idx}>
                        <ol className="seats" type="A">
                            <li className="seat">
                                <input type="checkbox" disabled={checkDisableSeat(ele[0])} value={ele[0]} id={ele[0]}/>
                                <label htmlFor={ele[0]}>{ele[0]}</label>
                            </li>
                            <li className="seat">
                                <input type="checkbox" disabled={checkDisableSeat(ele[1])} id={ele[1]} value={ele[1]} />
                                <label htmlFor={ele[1]}>{ele[1]}</label> 
                            </li>
                            <li className="seat">
                                <input type="checkbox" disabled={checkDisableSeat(ele[2])} value={ele[2]} id={ele[2]} />
                                <label htmlFor={ele[2]}>{ele[2]}</label>
                            </li>
                        </ol>
                    </li>
                    )
           // })
        })
            
    }
    return (
        <div className="ss">
            <div>
                
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                <label>Choose Food:</label>
                <ul className="navbar-nav ml-auto nav-flex-icons ic">
                <li className="nav-item">
                                <a href="#" onClick={e => handleFood(e,'Burger Rs.50')} title='Burger Rs.50' className="nav-link waves-effect waves-light" >
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M464 256H48a48 48 0 0 0 0 96h416a48 48 0 0 0 0-96zm16 128H32a16 16 0 0 0-16 16v16a64 64 0 0 0 64 64h352a64 64 0 0 0 64-64v-16a16 16 0 0 0-16-16zM58.64 224h394.72c34.57 0 54.62-43.9 34.82-75.88C448 83.2 359.55 32.1 256 32c-103.54.1-192 51.2-232.18 116.11C4 180.09 24.07 224 58.64 224zM384 112a16 16 0 1 1-16 16 16 16 0 0 1 16-16zM256 80a16 16 0 1 1-16 16 16 16 0 0 1 16-16zm-128 32a16 16 0 1 1-16 16 16 16 0 0 1 16-16z"></path></svg>
                                </a>
                                <a href="#" onClick={e => handleFood(e,'Pizza Rs.100')} title='Pizza Rs.100' className="nav-link waves-effect waves-light" >
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M158.87.15c-16.16-1.52-31.2 8.42-35.33 24.12l-14.81 56.27c187.62 5.49 314.54 130.61 322.48 317l56.94-15.78c15.72-4.36 25.49-19.68 23.62-35.9C490.89 165.08 340.78 17.32 158.87.15zm-58.47 112L.55 491.64a16.21 16.21 0 0 0 20 19.75l379-105.1c-4.27-174.89-123.08-292.14-299.15-294.1zM128 416a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm48-152a32 32 0 1 1 32-32 32 32 0 0 1-32 32zm104 104a32 32 0 1 1 32-32 32 32 0 0 1-32 32z"></path></svg>
                                </a>
                            </li>                         
                        </ul>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                   
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                            <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => handleBack(e)}>Back</a>
                            </li>                           
                        </ul>
                    </div>
                </nav>
                {
                   food.length>0 && <div className="food">{
                    renderSelectedFood()
                        }
                    </div>
                }
            </div>
            <div className="row">
                <div className="column1">
                    <div className="plane">
                        <form onChange={e => handleSelectedSeatNumber(e)}>
                            <ol className="cabin fuselage">
                               { displaySeatNumbers()}
                                {/* <li className="row row--1">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox"   value="1A" id="1A" />
                                            <label htmlFor="1A">1A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" id="1B" value="1B" />
                                            <label htmlFor="1B">1B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="1C" id="1C" />
                                            <label htmlFor="1C">1C</label>
                                        </li>
                                    </ol>
                                </li>
                                <li className="row row--2">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox"   value="2A" id="2A" />
                                            <label htmlFor="2A">2A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="2B" id="2B" />
                                            <label htmlFor="2B">2B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="2C" id="2C" />
                                            <label htmlFor="2C">2C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--3">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="3A" id="3A" />
                                            <label htmlFor="3A">3A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="3B" id="3B" />
                                            <label htmlFor="3B">3B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="3C" id="3C" />
                                            <label htmlFor="3C">3C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--4">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox"   value="4A" id="4A" />
                                            <label htmlFor="4A">4A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="4B" id="4B" />
                                            <label htmlFor="4B">4B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="4C" id="4C" />
                                            <label htmlFor="4C">4C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--5">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="5A" id="5A" />
                                            <label htmlFor="5A">5A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="5B" id="5B" />
                                            <label htmlFor="5B">5B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="5C" id="5C" />
                                            <label htmlFor="5C">5C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--6">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox"   value="6A" id="6A" />
                                            <label htmlFor="6A">6A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="6B" id="6B" />
                                            <label htmlFor="6B">6B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="6C" id="6C" />
                                            <label htmlFor="6C">6C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--7">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="7A" id="7A" />
                                            <label htmlFor="7A">7A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="7B" id="7B" />
                                            <label htmlFor="7B">7B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="7C" id="7C" />
                                            <label htmlFor="7C">7C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--8">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="8A" id="8A" />
                                            <label htmlFor="8A">8A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"   value="8B" id="8B" />
                                            <label htmlFor="8B">8B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="8C" id="8C" />
                                            <label htmlFor="8C">8C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--9">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="9A" id="9A" />
                                            <label htmlFor="9A">9A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"  value="9B" id="9B" />
                                            <label htmlFor="9B">9B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox"  value="9C" id="9C" />
                                            <label htmlFor="9C">9C</label>
                                        </li>

                                    </ol>
                                </li>
                                <li className="row row--10">
                                    <ol className="seats" type="A">
                                        <li className="seat">
                                            <input type="checkbox" value="10A" id="10A" />
                                            <label htmlFor="10A">10A</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="10B" id="10B" />
                                            <label htmlFor="10B">10B</label>
                                        </li>
                                        <li className="seat">
                                            <input type="checkbox" value="10C" id="10C" />
                                            <label htmlFor="10C">10C</label>
                                        </li>
                                    </ol>
                                </li> */}
                            </ol>
                        </form>
                    </div>
                </div>
                <div className="column2">
                    <div className="seatInfo">
                        <form className="form-group">
                            {renderPassengerData(seatNumber)}
                        </form>
                        <div>
                            <button onClick={e => handleSubmitPassengerDetails(e)} className="btn btn-info seatBT">
                                Confirm Details
                            </button>
                        </div>                       
                    </div>
                </div>
            </div>

        </div>

    )
}
