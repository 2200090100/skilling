
import React, { useState,  useRef } from 'react'
import './BusMaintanance.css'
const dotenv = require('dotenv').config();

export default function BusMaintanance({ history }) {

  const [startCity, setStartCity] = useState('')
  const [destination, setDestination] = useState('')
  const [price, setPrice] = useState(0)
  const [time, setTime] = useState('')
  const [error, setError] = useState(false)
  const [errorMsg, setErrorMsg] = useState("")
  const [companyName, setCompanyName] = useState('')
  console.log(process.env.REACT_APP_BACKEND_URL)
  const backendBaseUrl=process.env.REACT_APP_BACKEND_URL

    const handleViewBuses = e => {
        e.preventDefault()
        history.push('/viewbuses')
    }    

    
    const handleUserSignOut = e => {
        e.preventDefault()
        sessionStorage.removeItem('authToken')
        localStorage.removeItem('reservedSeats')
        localStorage.removeItem('nameData')
        localStorage.clear()
        history.push('/')
    }

    const BusAddFunc=async(e)=>{
        e.preventDefault() 
        try {
            //console.log("client isAdmin:", isAdmin)
            const res = await fetch(backendBaseUrl+'/bus/create/', {
            headers: {
                'Content-Type': 'application/json'
            },
            method: "POST",
            body: JSON.stringify({companyName:companyName,startCity:startCity, destination:destination, pricePerSeat:price,starttime:time})
            })
        const data =  await res.json()
        console.log("client bus add response:",data,res.status)
        if(res.status==500)
        {
            setErrorMsg(data)
            setError(true)
            setTimeout(() => {
            setError(false)          
            }, 3000)
        }
        else
        {            
            
            //dispatch(login(data)) // {userInfo, token}
            //window.localStorage.setItem("login","success")
            //window.localStorage.setItem("loginuseremail",email)
            history.push('/Admin')
            //history.push("/home")
        }
            
        } catch (errorMsg) {
            console.log(errorMsg)
            setErrorMsg(errorMsg)
            setError(true)
            setTimeout(() => {
            setError(false)
            }, 3000)
        }
    }
   
    return (
        <div className="container">
            <div>
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                    <a href="/#" className="navbar-brand Company-Log">Admin - KLU Travels</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3" aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                            <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => handleViewBuses(e)}>View Buses</a>
                            </li>
                            {/* <li className="nav-item">
                                <a href="#" className="nav-link waves-effect waves-light" ><i className="fa fa-user user"></i></a>
                            </li> */}
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleUserSignOut(e)}>Sign-Out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <h2>Add Bus</h2>
            <section className="myform-area">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-lg-8">
                            <div className="form-area">
                                 {/* <div className="form-content">
                                    <h2>Login</h2>
                                    <div>                                        
                                            <br/>                                                                               
                                            <GoogleLogin onSuccess={googleSuccessMessage} onError={googleErrorMessage} />
                                        </div>
                                    
                                </div>  */}
                                <div className="form-input">
                                    <h2>Enter Details</h2>
                                    <form onSubmit={(e) => { BusAddFunc(e) }}>
                                    <div className="form-group">
                                            <input className="loginInfo" type="text" name="tarvelName" required onChange={e => setCompanyName(e.target.value)} />
                                            <label>Travels Name</label>
                                        </div>
                                        <div className="form-group">
                                            <input className="loginInfo" type="text" name="startcity" required onChange={e => setStartCity(e.target.value)} />
                                            <label>Start City</label>
                                        </div>
                                        <div className="form-group">
                                            <input className="loginInfo" type="text" name="destination" required onChange={e => setDestination(e.target.value)} />
                                            <label>Destination City</label>
                                        </div>
                                        <div className="form-group">
                                            <input className="loginInfo" type="text" name="price" required onChange={e => setPrice(e.target.value)} />
                                            <label> Seat Price</label>
                                        </div> 
                                        <div className="form-group">
                                            <input className="loginInfo" type="text" name="time" required onChange={e => setTime(e.target.value)} />
                                            <label> Start Time</label>
                                        </div>                                       
                                        <div className="myform-button">
                                            <button type="submit" className="myform-btn">Submit</button>
                                        </div>
                                        
                                    </form>
                                    {
                                        error && <div className="errorMessage">
                                            {errorMsg}
                                        </div>
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div >
    )
}
