import React, { useState, useEffect } from 'react'
import './ViewBuses.css'
import * as hisApiCall from '../BookedTicket/HistoryApifunc'
import * as apiCall from '../BusRouteSelection//routeSearchApifunc'
export default function ViewBuses({history}) {

    const [dataInp, setData] = useState([])
    const [error, setError] = useState(true)

    useEffect(()=>{
        //console.log(startCity.startCity, destination.destination)
        apiCall.getBusesFromApi()
            .then(response => response.data)
            .then(data => {
                setData(data)
                console.log(data)
                if(data.length==0)
                {
                    setError(true)
                    setTimeout(() => {
                    setError(false)          
                    }, 3000)
                }
            })
    })
    const handleUserSignOut = e => {
        e.preventDefault()
        sessionStorage.removeItem('authToken')
        localStorage.removeItem('reservedSeats')
        localStorage.removeItem('nameData')
        localStorage.clear()
        history.push('/')
    }
    const handleViewBuses = e => {
        e.preventDefault()
        history.push('/viewbuses')
    } 
    const handleAddBuses = e => {
        e.preventDefault()
        history.push('/admin')
    } 
    const renderFunc = () => {
        return dataInp.map((bus, idx) => {
            // let bId = bus._id
            return (
                <div key={idx} className="card mt-5 buslist">
                    <div className="row ml-3">
                        <div className="col-6 col-sm-3 mt-2 font-weight-bold ">Brand</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">From</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">To</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">Price</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">Start time</div>

                        <div className="w-100 d-none d-md-block"></div>

                        {/* {console.log(bus.seatArray)} */}
                        <div className="col-6 col-sm-3 mb-4">{bus.companyName}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.startCity}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.destination}</div>
                        <div className="col-6 col-sm-2 mb-4">Rs.{bus.pricePerSeat}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.starttime}</div>
                        {/* <div className="col-6 col-sm-4 mb-2 ml-0">
                            <button onClick={() => { handleBusSubmit(bus._id,bus.pricePerSeat,bus.companyName,bus.starttime) }} >View</button>
                        </div> */}
                        {/* <div className="col-6 col-sm-4 mb-2 ml-0">
                            <span className={reset ? "badge badge-danger ml-5" : "disabled"} onClick={e => handleBusReset(e)}>Reset</span>
                        </div> */}
                    </div>
                </div >
            )
        })
         

    }


    return (
        <div className="container">
            <div>
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                    <a href="/#" className="navbar-brand Company-Log">Admin - KLU Travels</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3" aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                        <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => handleAddBuses(e)}>Add Buse</a>
                            </li>
                            <li className="nav-item">
                                <a href="#" className="nav-link-color" onClick={e => handleViewBuses(e)}>View Buses</a>
                            </li>
                            {/* <li className="nav-item">
                                <a href="#" className="nav-link waves-effect waves-light" ><i className="fa fa-user user"></i></a>
                            </li> */}
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleUserSignOut(e)}>Sign-Out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <h2>View Buses</h2>
           
        <div className="">
            {renderFunc()}            
        
        {
            error && <div><p>
            No Data found.
        </p></div>
        }
        </div>
        </div>
    )
}
