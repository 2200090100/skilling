import React from 'react'
import './home.css'
export default function Home({ history }) {
    const handleSignin = e => {
        e.preventDefault()
        history.push('/login')
    }
    const handleSignUp = e => {
        e.preventDefault()
        history.push('/signup')
    }
    return (
        <div className='container maint-cnt'>
            <div className="header-nav">
                <span className="heading"> KLU Travels </span>
            </div>
            <div className="">
                
        <div className="slogan">
                <h1>
                        {/* <span>always Travel with KLU</span>                         */}
                        </h1>
                        {/* <div className="message">
                        
                            <div className="word1">Uniquely</div>
                            <div className="word2">Safely</div>
                            <div className="word3">with a smile</div>
                        </div> */}
                    
        </div>
            <a href="/#" onClick={e => handleSignin(e)} className="logBtn">                    
                    <span >Log in</span>
                </a>
                <a href="/#" onClick={e => handleSignUp(e)} className="regBtn">                    
                    <span >Register</span>
                </a>
            
            </div>
           
        </div>
    )
}


