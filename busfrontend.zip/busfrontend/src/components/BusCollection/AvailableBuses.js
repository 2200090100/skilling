import React, { useState, useEffect } from 'react'
import './AvailableBuses.css'
import * as hisApiCall from '../BookedTicket/HistoryApifunc'
export default function AvailableBuses({ value: dataBuses,handleActiveMenu: handleActiveMenu, setReservedSeatFunc : setReservedSeatFunc}) {

    const [reset, Setreset] = useState(false)
    
    const [clas, SetClas] = useState(true)    

const getBookedSeatNumbers =()=>{    
        const reservedSeats = []    
        const jdate = localStorage.getItem('date')
        const busId = localStorage.getItem("selectedBusId")
        hisApiCall.getBookedSeatsFromApi(busId,jdate)
        .then(response => response.data)
        .then(data => {
            console.log("Booked seats data:",data)
            if(data.length==0)
            {
                setReservedSeatFunc(reservedSeats)
                //console.log("Error while get booked seats")
            }
            else
            {
                //data.map()
                //setReservedSeat()
                data.map((tkt, idx) => {
                    let seatsArray = tkt.seatNumbers
                    console.log(seatsArray)
                    if (seatsArray) {
                    let seats = JSON.parse(seatsArray)
                    reservedSeats.splice.apply(reservedSeats, [0, 0].concat(seats));
                    }
                        
                })
                //localStorage.setItem("alreadyBookedSeats",reservedSeats)
                setReservedSeatFunc(reservedSeats)
                console.log("Reserved seats are:",reservedSeats)

            }
        })
    }
    const handleBusSubmit = (bId,price,companyName,starttime) => {
        console.log(bId)
        handleActiveMenu(true,false)
        localStorage.setItem("selectedBusId", bId)
        localStorage.setItem("price", price)
        localStorage.setItem('company',companyName)
        localStorage.setItem('starttime',starttime)
        getBookedSeatNumbers()
        //SetClas(false)
        
        //console.log("BusList BookNOw seatMenuActive:",seatActive)
    }


    const handleBusReset = (e) => {
        if (clas === false) {
            Setreset(true)
            SetClas(true)
            
        }
        localStorage.removeItem("selectedBusId")
        localStorage.removeItem("price")
    }


    const renderFunc = () => {
        return dataBuses.map((bus, idx) => {
            // let bId = bus._id
            return (
                <div key={idx} className="card mt-5 buslist">
                    <div className="row ml-3">
                        <div className="col-6 col-sm-3 mt-2 font-weight-bold ">Brand</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">From</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">To</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">Price</div>
                        <div className="col-6 col-sm-2 mt-2 font-weight-bold ">Start time</div>

                        <div className="w-100 d-none d-md-block"></div>

                        {/* {console.log(bus.seatArray)} */}
                        <div className="col-6 col-sm-3 mb-4">{bus.companyName}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.startCity}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.destination}</div>
                        <div className="col-6 col-sm-2 mb-4">Rs.{bus.pricePerSeat}</div>
                        <div className="col-6 col-sm-2 mb-4">{bus.starttime}</div>
                        <div className="col-6 col-sm-4 mb-2 ml-0">
                            <button className={clas ? "btn btn-primary btn-md" : "btn btn-primary btn-md disabled"} onClick={() => { handleBusSubmit(bus._id,bus.pricePerSeat,bus.companyName,bus.starttime) }} >Book Now</button>
                        </div>
                        {/* <div className="col-6 col-sm-4 mb-2 ml-0">
                            <span className={reset ? "badge badge-danger ml-5" : "disabled"} onClick={e => handleBusReset(e)}>Reset</span>
                        </div> */}
                    </div>
                </div >
            )
        })

    }


    return (
        <div className="">
            {renderFunc()}            
        </div>

    )
}
