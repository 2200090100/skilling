import axios from 'axios'
const dotenv = require('dotenv').config()
export async function getRoutesFromApi(startCity, destination, starttime) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/filter"
    console.log(process.env.REACT_APP_BACKEND_URL)
    let incoming = await axios.post(baseURL, { startCity:startCity, destination:destination,starttime:starttime })
    return incoming
}
export async function getBusesFromApi() {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/"
    console.log(process.env.REACT_APP_BACKEND_URL)
    let incoming = await axios.get(baseURL)
    return incoming
}