import React, { useEffect, useState } from 'react'
import './BusRouteSelection.css'
import * as apiCall from './routeSearchApifunc'
import AvailableBuses from '../BusCollection/AvailableBuses'
export default function BusRouteSelection({handleActiveMenu: handleActiveMenu,setReservedSeatFunc:setReservedSeatFunc}) {    

    const [dataBuses, setData] = useState("")
    const [startCity, setStartCity] = useState('')
    const [destination, setDestination] = useState('')
    const [starttime, setStartTime] = useState('')
    const [error, setError] = useState(false)
    //const [seatActive, SetIsSeatActive] = useState(false)

    // useEffect(() => {        
    //     handleActiveMenu(false,false)
    // }, [handleActiveMenu])

    const handleToCity = e => {
        e.preventDefault()
        setDestination({ destination: e.target.value })
        localStorage.setItem("destination", e.target.value)
    }
    const handleTime = e => {
        e.preventDefault()
        setStartTime({ starttime: e.target.value })
        localStorage.setItem("starttime", e.target.value)
    }
    const renderAvailableBuses = (dataBuses) => {
        if (Object.keys(dataBuses).length > 0) {
            return (<AvailableBuses value={dataBuses} handleActiveMenu={handleActiveMenu} setReservedSeatFunc={setReservedSeatFunc} />)
        }
    }
    const handleFromCity = e => {
        e.preventDefault()
        setStartCity({ startCity: e.target.value })
        localStorage.setItem("start", e.target.value)
        console.log(startCity)
    }

    const handleGetAailableBuses = e => {
        e.preventDefault()
        console.log(startCity.startCity, destination.destination)
        apiCall.getRoutesFromApi(startCity.startCity, destination.destination,starttime.starttime)
            .then(response => response.data)
            .then(data => {
                setData(data)
                console.log(data)
                if(data.length==0)
                {
                    setError(true)
                    setTimeout(() => {
                    setError(false)          
                    }, 3000)
                }
            })
    }

    const handleDate = e => {
        e.preventDefault()
        //    console.log(e.target.value)
        localStorage.setItem("date", e.target.value)
    }
    
    return (
        <div className="rdc">
            <div className="form-group inline"></div>
            <div className="main-container">
                <form className="form-inline" onSubmit={e => handleGetAailableBuses(e)}>
                    <select name="ad_account_selected" data-style="btn-new" className="selectpicker" onChange={e => { handleFromCity(e) }}>
                        <option>FROM</option>
                        <option>Vijayawada</option>
                        <option>Chennai</option>
                        <option>Bangalore</option>
                    </select>
                    <select name="ad_account_selected" data-style="btn-new" className="selectpicker" onChange={e => { handleToCity(e) }}>
                        <option>TO</option>
                        <option>Hyderabad</option>
                        <option>Coimbatore</option>
                        <option>Vishakapatnam</option>
                        <option>Bangalore</option>
                        <option>Chennai</option>
                    </select>
                    <input onChange={e => { handleDate(e) }} type="date"></input>
                    <select name="ad_account_selected" data-style="btn-new" className="selectpicker" onChange={e => { handleTime(e) }}>
                    <option>start time</option>
                        <option>08:00 AM</option>
                        <option>08:45 PM</option>
                        <option>09:45 PM</option>                        
                    </select>
                    <input type="submit" value="Search" className=" btn btn-primary btn-md getRoute" />
                     
                </form>
                {
                     error && <div><p>
                     No Data found.
                 </p></div>
                }
                <div>
                    {renderAvailableBuses(dataBuses)}
                </div>
            </div>
        </div>
    )
}
