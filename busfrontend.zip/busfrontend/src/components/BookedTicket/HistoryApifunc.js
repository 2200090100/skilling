import axios from 'axios'
const dotenv = require('dotenv').config()
export async function getHistoryFromApi(email) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/history"
    console.log(process.env.REACT_APP_BACKEND_URL)
    let result = await axios.post(baseURL, {email})
    return result
}
export async function postHistoryToApi(tkt) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/ticketdetails"
    console.log(process.env.REACT_APP_BACKEND_URL)
    let result = await axios.post(baseURL, {tkt})
    return result
}
export async function getTicketFromApi(bookingid) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/getticketDetails/?bookingId="+bookingid
    console.log(process.env.REACT_APP_BACKEND_URL)
    console.log('history Api:',bookingid)
    let result = await axios.get(baseURL)
    return result
}
export async function postTicketCancelFromApi(bookingId) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/cancelticketDetails"
    console.log(process.env.REACT_APP_BACKEND_URL)
    console.log('history Api cancel ticket:',bookingId)
    let result = await axios.post(baseURL,{bookingId})
    return result
}

export async function getBookedSeatsFromApi(busid, jdate) {
    const baseURL = process.env.REACT_APP_BACKEND_URL+"/bus/getBookedSeats"
    console.log(process.env.REACT_APP_BACKEND_URL)
    console.log('history Api getBookedSeatsFromApi bus id, jdate:',busid, jdate)
    let result = await axios.post(baseURL,{busid,jdate})
    
    return result
}
