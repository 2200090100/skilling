import React from 'react'
import './BookedTicket.css'
import '../SigninUp/login.css'
import * as hisApiCall from './HistoryApifunc'

export default function BookedTicket({ history }) {

    const handleSignOut = e => {
        e.preventDefault()
        sessionStorage.removeItem('authToken')
        localStorage.removeItem('reservedSeats')
        localStorage.removeItem('nameData')
        localStorage.clear()
        history.push('/')
    }
    const handleBookAgainIcon = e => {
        e.preventDefault()
        localStorage.removeItem("reservedSeats")
        localStorage.removeItem("nameData")
        localStorage.removeItem('start')
        localStorage.removeItem('destination')
        localStorage.removeItem('date')
        localStorage.removeItem("selectedBusId")
        localStorage.removeItem("food")
        history.push('/booking')
    }

    const handleHistory = e => {
        e.preventDefault()        
        history.push('/history')
    }
    const handleCancel =async(e) => {
        e.preventDefault()
        
        if(window.confirm("Are you sure?"))
        {
            const bookingId =localStorage.getItem("ticketId")
            hisApiCall.postTicketCancelFromApi(bookingId)
            .then(response => response.data)
            .then(data => {
                console.log(data)
                if(data.length==0)
                {
                    console.log("Error while cancel ticket")
                }
                else
                {
                    alert('Ticket cancelled, will refund money with in 5 days!')
                    history.push('/booking')
    
                }
            })
        }
    }
    const getLocationData = () => {
        let from = localStorage.getItem("start")
        let to = localStorage.getItem("destination")
        return (
            <div>
                <p>From:  {from}</p>
                <p>To:  {to}</p>
            </div>
        )
    }
    const checkRequestFromHistory=()=>{
        const isHis=localStorage.getItem('isFromHistory')
        return isHis=="true";
    }
    const getPassengerName = () => {
        let nameArray = localStorage.getItem("nameData")
        let names = JSON.parse(nameArray)
        return names.map((name, idx) => {
            return (
                <div key={idx}>
                    <p className="names">{name}</p>
                </div>
            )
        })
    }
    const getFood = () => {
        let foodArray = localStorage.getItem("food")
        let foods = JSON.parse(foodArray)
        return foods.map((food, idx) => {
            return (
                <div key={idx}>
                    <p className="names">{food}</p>
                </div>
            )
        })
    }
    const getSeatNumbers = () => {
        let noArray = localStorage.getItem("reservedSeats")
        let arr = JSON.parse(noArray)
        return arr.map((element, idx) => {
            return (
                <div key={idx}>
                    <p className="seatno">{element}</p>
                </div>
            )
        })
    }
    const getIdNumber = () => {
        let tokenData = localStorage.getItem("ticketId")
        return (
            <p className="idData">
                {tokenData}
            </p>
        )
    }
    const getDateValue = () => {
        let dat = localStorage.getItem("date")
        let time = localStorage.getItem('starttime')
        return (<p>On: {dat}, {time} (Hourly commute)</p>)
    }
    return (

        <div className="container">
            <div>
                <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                    <a href="/#" className="navbar-brand Company-Log">KLU Travels</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3" aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                        <ul className="navbar-nav ml-auto nav-flex-icons ic">
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleBookAgainIcon(e)}>Book Again</a>
                            </li>
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleHistory(e)}><span> Booking History </span></a>
                            </li>
                            <li className="nav-item">
                                <a href="/#" className="nav-link-color" onClick={e => handleSignOut(e)}>Sign-Out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div className="tpMain">
               {
                !checkRequestFromHistory() &&(
                <form  onSubmit={(e) => { handleCancel(e) }}>
            
                    <div className="myform-button">
                        <button type="submit" className="myform-btn">Cancel</button>
                    </div>
                </form>)
                }
                <article className="ticket">
                    <header className="ticket__wrapper">
                        <div className="ticket__header">
                            1 🎟 KLU TRAVELS
                        </div>
                    </header>
                    <div className="ticket__divider">
                        <div className="ticket__notch"></div>
                        <div className="ticket__notch ticket__notch--right"></div>
                    </div>
                    <div className="ticket__body">
                        <section className="ticket__section">
                            {getLocationData()}
                            {getSeatNumbers()}
                            <span> Your seats are together {getDateValue()}</span>
                        </section>
                        <section className="ticket__section">
                            <h3>Passenger Names</h3>
                            {getPassengerName()}
                        </section>
                        <section className="ticket__section">
                            <h3>Food</h3>
                            {getFood()}
                        </section>
                        <section className="ticket__section">
                            <h3>Payment Method</h3>
                            <p>Credit Card</p>
                        </section>
                    </div>
                    <footer className="ticket__footer">
                        <p>Transaction-ID</p>
                        {getIdNumber()}
                    </footer>
                </article>
            </div>

        </div>

    )
}
