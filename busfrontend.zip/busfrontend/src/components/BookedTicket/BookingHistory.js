import React, { useState, useEffect } from 'react'
import './BookedTicket.css'
import * as hisApiCall from './HistoryApifunc'

export default function BookingHistory({ history }) {
    const [dataInp, setData] = useState([])
    const [error, setError] = useState(true)

    const handleViewTicket=(e,bookingId)=>{
        e.preventDefault()
        console.log("View Ticket:",bookingId)
        //get ticket details from History table
        //then assign to localStorage and navigate to ticket page
        hisApiCall.getTicketFromApi(bookingId)
        .then(response => response.data)
        .then(data => {
            console.log(data)
            if(data.length==0)
            {
                setError(true)
                setTimeout(() => {
                setError(false)          
                }, 3000)
            }
            else
            {
                setError(false) 
                localStorage.setItem("reservedSeats",data.seatNumbers)
                localStorage.setItem("nameData",data.passengers)
                localStorage.setItem('start',data.startCity)
                localStorage.setItem('destination',data.destination)
                localStorage.setItem('date',data.journeydate)
                localStorage.setItem("selectedBusId",data.busId)
                localStorage.setItem('ticketId',data._id) 
                localStorage.setItem('isFromHistory',true) 
                localStorage.setItem('starttime',data.starttime)
                localStorage.setItem('food',data.food)
                history.push('/getTicket')

            }
        })

    }
    const handleCancelTicket=(e,bookingId)=>{
        e.preventDefault()
        if(window.confirm("Are you sure?"))
        {
            //update ticket isCancelled = true in DB
            hisApiCall.postTicketCancelFromApi(bookingId)
            .then(response => response.data)
            .then(data => {
                console.log(data)
                if(data.length==0)
                {
                    setError(true)
                    setTimeout(() => {
                    setError(false)          
                    }, 3000)
                }
                else
                {
                    setError(false) 
                    alert('Ticket cancelled, will refund money with in 5 days!')
                    //history.push('/history')
                    window.location.reload(false);
    
                }
            })

            
        }
    }
    const handleSignOut = e => {
        e.preventDefault()
        sessionStorage.removeItem('authToken')
        localStorage.removeItem('reservedSeats')
        localStorage.removeItem('nameData')
        localStorage.clear()
        history.push('/')
    }
    const handleBookAgainIcon = e => {
        e.preventDefault()
        localStorage.removeItem("reservedSeats")
        localStorage.removeItem("nameData")
        localStorage.removeItem('start')
        localStorage.removeItem('destination')
        localStorage.removeItem('date')
        localStorage.removeItem("selectedBusId")
        localStorage.removeItem('starttime')
        localStorage.removeItem('food')
        history.push('/booking')
    }
    useEffect(()=>{
        console.log(localStorage.getItem("loginuseremail"))
        hisApiCall.getHistoryFromApi(localStorage.getItem("loginuseremail"))
            .then(response => response.data)
            .then(data => {
                setData(data)
                console.log(data)
                if(data.length==0)
                {
                    setError(true)
                    setTimeout(() => {
                    setError(false)          
                    }, 3000)
                }
                else
                {
                    setData(data)
                    setError(false) 
                }
            })
    },[localStorage]);

    const renderBookedTkts =()=>{
        return dataInp.map((bus, idx) => {
            return(
            <form>
                    <div key={idx} className="card mt-6 buslist">
                        <div className="row ml-1">
                            <div className="col-4 col-sm-1 mt-2 font-weight-bold ">Brand</div>
                            <div className="col-4 col-sm-2 mt-2 font-weight-bold ">From</div>
                            <div className="col-2 col-sm-1 mt-2 font-weight-bold ">To</div>
                            <div className="col-2 col-sm-1 mt-2 font-weight-bold ">Price</div>
                            <div className="col-2 col-sm-2 mt-2 font-weight-bold ">Date of Journey</div>
                            <div className="col-2 col-sm-1.01 mt-2 font-weight-bold ">Cancelled</div>
                            
                                <div className="col-1 col-sm-2 mt-2" >
                                <a href="#" className="nav-link-color" onClick={e => handleViewTicket(e,bus._id)}>View Details</a>
                                </div>
                               
                            <div className="w-100 d-none d-md-block"></div>

                            <div className="col-4 col-sm-1 mb-2">{bus.companyName}</div>
                            <div className="col-4 col-sm-2 mb-2">{bus.startCity}</div>
                            <div className="col-2 col-sm-1 mb-4">{bus.destination}</div>
                            <div className="col-2 col-sm-1 mb-4">Rs.{bus.pricePerSeat}</div>
                            <div className="col-4 col-sm-2 mb-4">{bus.journeydate}</div>
                            <div className="col-2 col-sm-1.01 mb-4">{bus.isCancelled?"Yes":"No"}</div>
                            {
                                !bus.isCancelled &&(
                                    <div className="col-1 col-sm-2 mt-2">
                                    <a href="#" className="nav-link-color" onClick={e => handleCancelTicket(e,bus._id)}>Cancel Ticket</a>
                                    </div>
                                    )
                            }
                        
                            
                        </div>
                    </div >
                    </form>
            )
        })
    }
    const renderFunction = () => {
       // return(<div><p>This is History</p></div>)
       
        // return dataInp.map((bus, idx) => {
            // let bId = bus._id
            return (
               
                <div className="container">
                    <div>
                        <nav className="mb-4 navbar navbar-expand-lg navbar-dark bg-unique hm-gradient">
                            <a href="/#" className="navbar-brand Company-Log">KLU Travels</a>
                            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3" aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="navbarSupportedContent-3">
                                <ul className="navbar-nav ml-auto nav-flex-icons ic">
                                    <li className="nav-item">
                                        <a href="/#" className="nav-link-color" onClick={e => handleBookAgainIcon(e)}>Book Again</a>
                                    </li>
                                    <li className="nav-item">
                                        <a href="#" className="nav-link waves-effect waves-light" ><i className="fa fa-user user"></i></a>
                                    </li>
                                    <li className="nav-item">
                                        <a href="/#" className="nav-link-color" onClick={e => handleSignOut(e)}>Sign-Out</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div className="tpMain1">
                    
                    {
                        <div>
                        {renderBookedTkts()}
                        </div>
                    }
               
                {
                        error && <div><p>
                        No Data found.
                    </p></div>
                } 
                </div>
                </div>
               
            )
        

    }

    return (
        <div className="">
            {renderFunction()}
        </div>

    )
};
