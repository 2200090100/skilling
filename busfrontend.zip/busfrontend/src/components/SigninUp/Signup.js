import React, { useState, useRef } from "react";
//import { FaFacebookF, FaTwitterSquare } from "react-icons/fa";
import "./signup.css";
const dotenv = require('dotenv').config()
export default function Signup({ history }) {
    //const ref = useRef();
    const [username, setUsername] = useState("")
    const [email, setEmail] = useState("")
    const [mobile, setMobile] = useState("")
    const [gender, setGender] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState(false)
    const [sucess, setSucess] = useState(false)
    const [errorMsg, setErrorMsg] = useState("")
    const backendBaseUrl=process.env.REACT_APP_BACKEND_URL

    let [newUser, setnewUser] = useState({});
    const handleChangeEvent = (e, field) => {
        let fieldValue = e.target.value;
        
        if (field === 'email') {
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if (fieldValue.match(mailformat)) {
                setnewUser({ ...newUser, [field]: fieldValue })
                return true
            } else {
                alert("You have entered an invalid email address!");                             
                return false
            }
        } else if (field === 'password') {
            var passwordFormat = /^[A-Za-z]\w{7,14}$/;
            if (fieldValue.match(passwordFormat)) {
                setnewUser({ ...newUser, [field]: fieldValue })
                return true
            }else{
                alert("Input Password and Submit [7 to 15 characters which contain only characters, numeric digits, underscore and first character must be a letter]")
                return false
            }
        }
        
        setnewUser({...newUser, [field]: fieldValue });
        
    };

    // sign in
    const getToSignIn = (e) => {
        e.preventDefault();
        history.push("/login");
    };

    // submiting data to backend
    const submitData = async(e) => {
        e.preventDefault();
        try {
            //const baseUrl=process.env.BACKEND_URL+'/auth/register/';
            const res = await fetch(backendBaseUrl+'/auth/register/', {
              headers: {
                "Content-Type": 'application/json'
              },
              method: "POST",
              body: JSON.stringify(newUser)
            })
      
            const data = await res.json()
            console.log(res.status)
            if(res.status==500)
            {
              setErrorMsg(data)
              setSucess(false)
              setError(true)
              setTimeout(() => {
                setError(false)          
              }, 3000)
            }
            else
            {
              setSucess(true)
              setTimeout(() => {
                setSucess(false)
                history.push("/login");
              }, 3000)
            }
            
          } catch (errormsg) {
            setErrorMsg(errorMsg)
            setError(true)
            setTimeout(() => {
              setError(false)
              
            }, 3000)
          }     
      
        
    };

    return ( 
        <div className = "container" >
        <div className = "flex-container" >
        <div className = "row full" >
        <div className = "col-md-12" >
        <div className = "form-container" >
        {/* <div className = "form-container-in" > </div>  */}
        <div className = "row sgnUp " >
        {/* <div className = "col-md-6" >
        <h3 className = "lead-text mn-txt" > Sign Up </h3> 
        </div>  */}
        <div className = "left-divider" >
        <div className = "col-md-6" >
        <form onSubmit = {
            (e) => submitData(e) } >
        <div className = "form-group2" >
            <h2>Enter Details</h2>
        <label htmlFor = "name" > Name: </label> 
        <input id = "name"
        type = "text"
        className = "form-control sgnUp"
        onChange = {
            (e) => handleChangeEvent(e, "username") }
        /> </div> 
        <div class = "form-group2" >
        <label htmlFor = "email" > Email - ID*: </label> 
        <input required id = "email" 
        type = "email"
        className = "form-control sgnUp"
        onBlurCapture = {
            (e) => handleChangeEvent(e, "email") }
        /> </div> 
        <div class = "form-group2" >
        <label htmlFor = "mob-number" > Mobile - No.*: </label> 
        <input required id = "mob-number"
        type = "text"
        className = "form-control sgnUp"
        onBlurCapture = {
            (e) => handleChangeEvent(e, "mobile") }
        /> </div> 
        <label>Gender*</label>
        <br/>
        <div class = "form-check form-check-inline rd" >
        <input required class = "form-check-input"       
        type = "radio"
        id = "Male"
        name = "gender"
        value = "Male"
        onChange = {
            (e) => handleChangeEvent(e, "gender") }
        /> <label class = "form-check-label"
        htmlFor = "Male" >
        Male </label> </div> 
        <div class = "form-check form-check-inline rd" >
        <input required class = "form-check-input"
        type = "radio"
        id = "Female"
        name = "gender"
        value = "Female"
        onChange = {
            (e) => handleChangeEvent(e, "gender") }
        /> 
        <label class = "form-check-label"
        htmlFor = "Female" >
        Female </label> </div> 
        <div class = "form-group2" >
        <label htmlFor = "password" > Password*: </label> 
        <input required id = "password"
        type = "password"
        className = "form-control sgnUp"
        onBlurCapture = {
            (e) => handleChangeEvent(e, "password") }
        /> </div> 
        
        <label>Admin</label>
        <br/>
        <div class = "form-check form-check-inline rd" >
        <input required class = "form-check-input"       
        type = "radio"
        id = "true"
        name = "isAdmin"
        value = "true"
        onChange = {
            (e) => handleChangeEvent(e, "isAdmin") }
        />
        <label class = "form-check-label"
        htmlFor = "Yes" >
        Yes </label>  
        </div><div class = "form-check form-check-inline rd" >
        <input required class = "form-check-input"
        type = "radio"
        id = "false"
        name = "isAdmin"
        value = "false"
        onChange = {
            (e) => handleChangeEvent(e, "isAdmin") }
        /> 
        <label class = "form-check-label"
        htmlFor = "No" >
        No </label> </div> 

        <div class = "form-group2" >
        <input required type = "submit"
        value = "submit"
        className = "btn-primary btnn form-submit sub-btn sgnUp" />
        </div> <div>
        <small className = "form-text text-muted" >
        Already a User ?<a href = "/#"
        onClick = {
            (e) => getToSignIn(e) } >
        Sign-In </a></small> 
        {/* <span className = "signuptext" > }
        <a href = "/#"
        onClick = {
            (e) => getToSignIn(e) } >
        Sign-In </a> 
        {/* </span>  */}
        <br/>
        </div> 
        </form> 
        {
            error && <div className='errorMessage'>
                {errorMsg}
            </div>
        }
        </div> </div> </div> </div> </div> </div> </div> </div>
    );
}